from flask import Flask, jsonify, redirect, render_template, request, url_for

import config
import services
from services.gemini_client import GeminiError
from services.parser import ParseError, extract_text, form_to_text, read_job_description

app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY
app.config['MAX_CONTENT_LENGTH'] = config.MAX_UPLOAD_BYTES + 1024 * 1024


def index_error(message, form=None, status=400):
    return render_template('index.html', error=message, form=form or {}), status


@app.get('/')
def home():
    return render_template('home.html')


@app.get('/analyze')
def index():
    return render_template('index.html', error=None, form={})


@app.post('/analyse')
def analyse_cv():
    mode = request.form.get('input_mode', 'upload')
    try:
        if mode == 'form':
            cv_text = form_to_text(request.form)
        else:
            file = request.files.get('cv_file')
            if file is None or not file.filename:
                raise ParseError('Choose a PDF or DOCX file.')
            cv_text = extract_text(file)
        jd_text = read_job_description(request.form.get('job_description'))
    except ParseError as exc:
        return index_error(str(exc), request.form)
    try:
        result = services.analyse(cv_text, jd_text)
    except Exception:
        app.logger.exception('analysis failed')
        return index_error('The analysis failed. Try again with different text.', request.form, 500)
    services.save(result)
    return redirect(url_for('results', rid=result['id']))


@app.get('/results/<rid>')
def results(rid):
    result = services.get(rid)
    if result is None:
        return index_error('That result has expired. Run the analysis again.', None, 404)
    return render_template('results.html', r=result)


@app.post('/ask')
def ask():
    data = request.get_json(silent=True) or {}
    question = (data.get('question') or '').strip()
    if not question or len(question) > config.MAX_QUESTION_CHARS:
        return jsonify(error='Enter a question of up to 1000 characters.'), 400
    try:
        answer = services.ask(data.get('result_id', ''), question)
    except LookupError:
        return jsonify(error='This result has expired. Run the analysis again.'), 404
    except GeminiError as exc:
        return jsonify(error=str(exc)), 502
    return jsonify(answer=answer)


@app.post('/feedback')
def feedback():
    data = request.get_json(silent=True) or {}
    try:
        services.save_feedback(data.get('result_id', ''), data.get('rating'), data.get('comment', ''))
    except LookupError:
        return jsonify(error='This result has expired.'), 404
    except (ValueError, TypeError):
        return jsonify(error='Choose a rating from 1 to 5.'), 400
    return jsonify(message='Thank you for your feedback.')


@app.errorhandler(413)
def too_large(_):
    return index_error('The file is larger than the 5 MB limit.', None, 413)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)