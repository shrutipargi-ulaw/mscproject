import config
from services.preprocessing import clean_text

VOCAB_SET = set(config.SKILLS_VOCAB)
ALIASES = {k: v for k, v in config.SYNONYMS.items() if len(k) >= config.ALIAS_MIN_LENGTH and v in VOCAB_SET}

TERM_MAP = {}
for skill in config.SKILLS_VOCAB:
    TERM_MAP.setdefault(clean_text(skill), skill)
for alias, canonical in ALIASES.items():
    TERM_MAP.setdefault(clean_text(alias), canonical)
TERM_MAP.pop('', None)
MAX_N = max(len(term.split()) for term in TERM_MAP)


def extract_skills(clean):
    tokens = clean.split()
    found, i, total = set(), 0, len(tokens)
    while i < total:
        step = 1
        for n in range(min(MAX_N, total - i), 0, -1):
            gram = ' '.join(tokens[i:i + n])
            if gram in TERM_MAP:
                found.add(TERM_MAP[gram])
                step = n
                break
        i += step
    return sorted(found)


def compare(cv_skills, job_skills):
    cv_set = set(cv_skills)
    job_set = set(job_skills)
    job_tech = {s for s in job_set if s not in config.SOFT_SKILLS}
    job_soft = job_set - job_tech

    def ratio(subset):
        return len(subset & cv_set) / len(subset) if subset else None

    cov_all = ratio(job_set)
    cov_all = 0.0 if cov_all is None else cov_all
    cov_tech = ratio(job_tech)
    cov_soft = ratio(job_soft)
    return {
        'matched': sorted(job_set & cv_set),
        'missing': sorted(job_set - cv_set),
        'missing_technical': sorted(job_tech - cv_set),
        'missing_soft': sorted(job_soft - cv_set),
        'cov_all': cov_all,
        'cov_tech': cov_all if cov_tech is None else cov_tech,
        'cov_soft': cov_all if cov_soft is None else cov_soft,
    }