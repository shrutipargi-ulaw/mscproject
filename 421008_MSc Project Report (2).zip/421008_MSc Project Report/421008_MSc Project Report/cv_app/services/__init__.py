import json
import secrets
import threading
from collections import OrderedDict
from datetime import datetime, timezone

import config

from . import classifier, gemini_client, scorer, skills
from .gemini_client import GeminiError
from .preprocessing import prepare_job, prepare_resume

_STORE = OrderedDict()
_LOCK = threading.Lock()


def save(result):
    with _LOCK:
        _STORE[result['id']] = result
        while len(_STORE) > config.MAX_SESSIONS:
            _STORE.popitem(last=False)


def get(result_id):
    with _LOCK:
        return _STORE.get(result_id)


def add_ai_sections(result):
    result['ai_errors'] = []
    try:
        result['suggestions'] = gemini_client.suggest_improvements(result)
    except GeminiError as exc:
        result['ai_errors'].append(f'CV suggestions: {exc}')
    try:
        result['careers'] = gemini_client.career_guidance(result)
    except GeminiError as exc:
        result['ai_errors'].append(f'Career guidance: {exc}')


def analyse(cv_text, jd_text):
    resume = prepare_resume(cv_text)
    job_clean = prepare_job(jd_text)
    cv_skills = skills.extract_skills(resume['clean'])
    job_skills = skills.extract_skills(job_clean)
    comparison = skills.compare(cv_skills, job_skills)
    similarity_raw = scorer.similarity(resume['embed'], job_clean)
    result = {
        'id': secrets.token_urlsafe(8),
        'created': datetime.now(timezone.utc).isoformat(),
        'cv_text': cv_text,
        'jd_text': jd_text,
        'cv_skills': cv_skills,
        'job_skills': job_skills,
        'comparison': comparison,
        'score': scorer.score(similarity_raw, comparison),
        'categories': classifier.predict_categories(resume['model']),
        'suggestions': None,
        'careers': None,
        'ai_errors': [],
        'chat': [],
    }
    add_ai_sections(result)
    return result


def ask(result_id, question):
    result = get(result_id)
    if result is None:
        raise LookupError('Result not found.')
    answer = gemini_client.follow_up(result, question)
    with _LOCK:
        result['chat'].append({'q': question, 'a': answer})
    return answer


def save_feedback(result_id, rating, comment):
    result = get(result_id)
    if result is None:
        raise LookupError('Result not found.')
    rating = int(rating)
    if rating < 1 or rating > 5:
        raise ValueError('Rating must be between 1 and 5.')
    record = {
        'time': datetime.now(timezone.utc).isoformat(),
        'result_id': result_id,
        'score': result['score']['value'],
        'band': result['score']['band'],
        'rating': rating,
        'comment': (comment or '').strip()[:config.MAX_QUESTION_CHARS],
    }
    config.DATA_DIR.mkdir(exist_ok=True)
    with _LOCK:
        with open(config.FEEDBACK_PATH, 'a', encoding='utf-8') as f:
            f.write(json.dumps(record) + '\n')