import joblib
import numpy as np

import config

TFIDF = joblib.load(config.TFIDF_PATH)
CLF = joblib.load(config.CLASSIFIER_PATH)
ENCODER = joblib.load(config.LABEL_ENCODER_PATH)


def predict_categories(model_text, top_k=3):
    features = TFIDF.transform([model_text])
    scores = CLF.decision_function(features)[0]
    order = np.argsort(scores)[::-1][:top_k]
    return [str(name) for name in ENCODER.inverse_transform(CLF.classes_[order])]