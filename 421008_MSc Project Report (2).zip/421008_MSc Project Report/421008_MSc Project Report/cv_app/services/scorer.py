import numpy as np
from sentence_transformers import SentenceTransformer

import config

EMBEDDER = SentenceTransformer(config.EMBED_MODEL)


def chunk_text(text, size=config.CHUNK_WORDS):
    words = text.split()
    return [' '.join(words[i:i + size]) for i in range(0, max(len(words), 1), size)]


def embed_doc(text):
    chunks = chunk_text(text)
    emb = EMBEDDER.encode(chunks, normalize_embeddings=True, show_progress_bar=False)
    vec = emb.sum(axis=0)
    return vec / max(float(np.linalg.norm(vec)), 1e-9)


def similarity(resume_embed_text, job_clean_text):
    return float(embed_doc(resume_embed_text) @ embed_doc(job_clean_text))


def band(value):
    if value < config.BAND_LOW_MAX:
        return config.BAND_NAMES[0]
    if value < config.BAND_HIGH_MIN:
        return config.BAND_NAMES[1]
    return config.BAND_NAMES[2]


def score(similarity_raw, comparison):
    sim_norm = float(np.clip((similarity_raw - config.SIM_LO) / (config.SIM_HI - config.SIM_LO), 0, 1))
    weights = config.WEIGHTS
    values = {'semantic': sim_norm, 'tech': comparison['cov_tech'], 'soft': comparison['cov_soft']}
    names = {'semantic': 'Semantic similarity (scaled)', 'tech': 'Technical skill coverage', 'soft': 'Soft skill coverage'}
    components = [
        {'name': names[k], 'weight': weights[k], 'value': values[k], 'points': 100 * weights[k] * values[k]}
        for k in ('semantic', 'tech', 'soft') if weights[k] > 0
    ]
    total = sum(c['points'] for c in components)
    label = band(total)
    parts = ', '.join(f"{c['name'].lower()} (weight {c['weight']:.2f})" for c in components)
    contributions = ' '.join(f"{c['name']} contributed {c['points']:.1f} points." for c in components)
    return {
        'value': round(total, 1),
        'band': label,
        'components': components,
        'similarity_raw': round(similarity_raw, 3),
        'similarity_pct': round(sim_norm * 100, 1),
        'explanation': f'The score is 100 multiplied by a weighted sum of {parts}. {contributions}',
        'band_rule': f'Below {config.BAND_LOW_MAX} is Low fit, from {config.BAND_LOW_MAX} up to {config.BAND_HIGH_MIN} is Moderate fit, and {config.BAND_HIGH_MIN} or above is High fit.',
    }