import io

from docx import Document
from pypdf import PdfReader

import config


class ParseError(Exception):
    pass


def extension(filename):
    return filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''


def read_pdf(data):
    reader = PdfReader(io.BytesIO(data))
    return '\n'.join((page.extract_text() or '') for page in reader.pages)


def read_docx(data):
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                parts.append(cell.text)
    return '\n'.join(parts)


def finalise_cv(text):
    text = text.strip()
    if len(text.split()) < config.MIN_CV_WORDS:
        raise ParseError('No readable CV text found. Scanned PDFs are not supported.')
    return text[:config.MAX_CV_CHARS]


def extract_text(file_storage):
    ext = extension(file_storage.filename or '')
    if ext not in config.ALLOWED_EXTENSIONS:
        raise ParseError('Upload a PDF or DOCX file.')
    data = file_storage.read()
    if not data:
        raise ParseError('The uploaded file is empty.')
    if len(data) > config.MAX_UPLOAD_BYTES:
        raise ParseError('The file is larger than the 5 MB limit.')
    try:
        text = read_pdf(data) if ext == 'pdf' else read_docx(data)
    except Exception:
        raise ParseError('The file could not be read.')
    return finalise_cv(text)


def form_to_text(form):
    parts = [form.get(field, '').strip() for field in config.FORM_FIELDS]
    return finalise_cv('\n'.join(p for p in parts if p))


def read_job_description(raw):
    text = (raw or '').strip()
    if len(text.split()) < config.MIN_JD_WORDS:
        raise ParseError('Paste a longer job description.')
    return text[:config.MAX_JD_CHARS]