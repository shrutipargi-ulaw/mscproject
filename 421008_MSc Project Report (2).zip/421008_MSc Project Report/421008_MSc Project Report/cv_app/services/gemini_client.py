from google import genai
from google.genai import types

import config


class GeminiError(Exception):
    pass


_client = genai.Client(api_key=config.GEMINI_API_KEY) if config.GEMINI_API_KEY else None


def generate(prompt):
    if _client is None:
        raise GeminiError('GEMINI_API_KEY is not set.')
    try:
        response = _client.models.generate_content(
            model=config.GEMINI_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(temperature=0.4),
        )
    except Exception as exc:
        raise GeminiError(f'Gemini request failed: {str(exc)[:200]}')
    text = (response.text or '').strip()
    if not text:
        raise GeminiError('Gemini returned an empty response.')
    return text


def fill(key, **values):
    return config.PROMPTS[key].format(**values) + config.PROMPTS['style_suffix']


def skill_text(skills):
    return ', '.join(skills[:30]) if skills else 'none'


def suggest_improvements(result):
    prompt = fill(
        'cv_suggestions',
        score=result['score']['value'],
        band=result['score']['band'],
        matched_skills=skill_text(result['comparison']['matched']),
        missing_skills=skill_text(result['comparison']['missing']),
        resume_text=result['cv_text'],
        job_description=result['jd_text'],
    )
    return generate(prompt)


def career_guidance(result):
    prompt = fill(
        'career_paths',
        predicted_category=result['categories'][0],
        top_categories=', '.join(result['categories']),
        matched_skills=skill_text(result['cv_skills']),
        resume_text=result['cv_text'],
    )
    return generate(prompt)


def follow_up(result, question):
    history = '\n'.join(f"Q: {t['q']}\nA: {t['a']}" for t in result['chat'][-6:]) or 'none'
    prompt = fill(
        'follow_up',
        score=result['score']['value'],
        band=result['score']['band'],
        predicted_category=result['categories'][0],
        matched_skills=skill_text(result['comparison']['matched']),
        missing_skills=skill_text(result['comparison']['missing']),
        resume_text=result['cv_text'],
        job_description=result['jd_text'],
        history=history,
        question=question,
    )
    return generate(prompt)