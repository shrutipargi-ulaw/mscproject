import re

import nltk
from nltk.corpus import stopwords

nltk.download('stopwords', quiet=True)

STOP = set(stopwords.words('english'))
BOILERPLATE = {'company', 'name', 'city', 'state'}


def clean_text(t):
    t = str(t).lower()
    t = re.sub(r'http\S+|www\S+', ' ', t)
    t = re.sub(r'[^a-z0-9+#.\s]', ' ', t)
    t = re.sub(r'(?<![a-z0-9])\.|\.(?![a-z0-9])', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def remove_stopwords(t):
    return ' '.join(w for w in t.split() if w not in STOP)


def strip_boiler(t):
    return ' '.join(w for w in t.split() if w not in BOILERPLATE)


def strip_boiler_phrases(t):
    t = re.sub(r'\bcompany name\b|\bcity state\b', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def prepare_resume(raw):
    clean = clean_text(raw)
    return {
        'clean': clean,
        'embed': strip_boiler_phrases(clean),
        'model': strip_boiler(remove_stopwords(clean)),
    }


def prepare_job(raw):
    return clean_text(raw)