import json
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / '.env')

ARTIFACT_DIR = BASE_DIR / 'artifacts'
DATA_DIR = BASE_DIR / 'data'
FEEDBACK_PATH = DATA_DIR / 'feedback.jsonl'

CLASSIFIER_PATH = ARTIFACT_DIR / 'resume_classifier.joblib'
TFIDF_PATH = ARTIFACT_DIR / 'tfidf_vectorizer.joblib'
LABEL_ENCODER_PATH = ARTIFACT_DIR / 'label_encoder.joblib'


def load_json(name):
    with open(ARTIFACT_DIR / name, encoding='utf-8') as f:
        return json.load(f)


MODEL_CONFIG = load_json('config.json')
SKILLS_VOCAB = load_json('skills_vocab.json')
SYNONYMS = load_json('synonyms.json')
SOFT_SKILLS = set(load_json('soft_skills.json'))
PROMPTS = load_json('prompt_templates.json')
METRICS = load_json('metrics_report.json')

EMBED_MODEL = MODEL_CONFIG['embedding_model']
CHUNK_WORDS = MODEL_CONFIG['embedding_chunk_words']
SIM_LO = MODEL_CONFIG['sim_lo']
SIM_HI = MODEL_CONFIG['sim_hi']
WEIGHTS = MODEL_CONFIG['scorer_weights']
BAND_LOW_MAX = MODEL_CONFIG['score_bands']['low_max']
BAND_HIGH_MIN = MODEL_CONFIG['score_bands']['high_min']
BAND_NAMES = ('Low fit', 'Moderate fit', 'High fit')
JOB_CATEGORIES = MODEL_CONFIG['job_categories']
CLASSES = MODEL_CONFIG['classifier']['classes']
ALIAS_MIN_LENGTH = MODEL_CONFIG['skill_extractor']['alias_min_length']
MAX_NGRAM = MODEL_CONFIG['skill_extractor']['max_ngram']

GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', '')
GEMINI_MODEL = os.environ.get('GEMINI_MODEL', 'gemini-3-flash-preview')
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret')

ALLOWED_EXTENSIONS = {'pdf', 'docx'}
MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MAX_CV_CHARS = 20000
MAX_JD_CHARS = 10000
MAX_QUESTION_CHARS = 1000
MAX_SESSIONS = 200

# Minimum word counts for validation
MIN_CV_WORDS = 10
MIN_JD_WORDS = 7  # Changed to 7-8 words minimum for job description

# Form fields for manual CV entry
FORM_FIELDS = ['summary', 'skills', 'experience', 'education']