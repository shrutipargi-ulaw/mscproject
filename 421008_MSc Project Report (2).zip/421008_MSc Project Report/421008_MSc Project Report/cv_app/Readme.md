# CV Analyser

A Flask web application that compares a CV with a target job description. It reports a compatibility score, detected and missing skills, semantic similarity, CV improvement suggestions and career recommendations. A Gemini model generates the suggestions and career guidance and answers follow-up questions.

The models were trained in Google Colab: a TF-IDF and Logistic Regression resume classifier, a rule-based compatibility scorer using sentence embeddings and skill coverage, and a vocabulary-based skill extractor.

## Requirements

- Python 3.10 or newer
- An internet connection. The first run downloads the sentence embedding model, and Gemini requests need network access.
- A free Gemini API key from Google AI Studio

## Project structure

```
cv_app/
├── app.py
├── config.py
├── requirements.txt
├── .env
├── artifacts/
├── services/
│   ├── __init__.py
│   ├── parser.py
│   ├── preprocessing.py
│   ├── skills.py
│   ├── scorer.py
│   ├── classifier.py
│   └── gemini_client.py
├── templates/
│   ├── base.html
│   ├── index.html
│   └── results.html
├── static/
│   └── style.css
└── data/
    └── feedback.jsonl
```

The `artifacts/` folder must contain these files exported from the Colab notebook:

- resume_classifier.joblib
- tfidf_vectorizer.joblib
- label_encoder.joblib
- skills_vocab.json
- synonyms.json
- soft_skills.json
- config.json
- prompt_templates.json
- metrics_report.json

The file `extractor_block_terms_not_applied.json` is not used by the application and can stay in the folder.

## Setup

1. Open the `cv_app` folder in VS Code and open a terminal in that folder.

2. Create and activate a virtual environment.

   Windows:

```
   python -m venv venv
   venv\Scripts\activate
```

   Mac or Linux:

```
   python3 -m venv venv
   source venv/bin/activate
```

3. Install the dependencies.

```
   pip install -r requirements.txt
```

4. Create the `.env` file in the project root with the following lines.

```
   GEMINI_API_KEY=your_api_key
   GEMINI_MODEL=gemini-3-flash-preview
   SECRET_KEY=a_long_random_string
```

   Model names change over time. If Gemini returns a model-not-found error, open Google AI Studio, choose a currently available free model and set its name in `GEMINI_MODEL`. Do not share or commit the `.env` file.

5. Create the data folder if it does not exist.

```
   mkdir data
```

## Run

```
python app.py
```

Open http://127.0.0.1:5000 in a browser. The first start takes longer because the embedding model is downloaded and loaded.

To stop the server, press Ctrl+C in the terminal.

## Use

1. Choose Upload PDF or DOCX, or choose Fill in a form and complete the fields.
2. Paste the target job description.
3. Click Analyse CV.
4. Read the results in order: compatibility score, score explanation, semantic similarity, skills, skill gaps, CV suggestions, career recommendations.
5. Optionally send feedback with a rating and comment. Feedback is appended to `data/feedback.jsonl`.
6. Use the follow-up box to ask Gemini questions about the same CV and job.

## Routes

| Method | Path | Purpose |
| --- | --- | --- |
| GET | / | Input page |
| POST | /analyse | Parse the CV, run the analysis and redirect to the results |
| GET | /results/<id> | Results page |
| POST | /ask | Follow-up question to Gemini |
| POST | /feedback | Store feedback |

## Configuration

All paths, limits and environment variables are read in `config.py`.

| Setting | Default |
| --- | --- |
| Maximum upload size | 5 MB |
| Maximum CV text | 20,000 characters |
| Maximum job description | 10,000 characters |
| Maximum question length | 1,000 characters |
| Results kept in memory | 200 |

## Notes and limitations

- Results and follow-up conversations are kept in memory only. They are lost when the server restarts.
- Uploaded files are read in memory and are not saved to disk. Only extracted text is kept for the session.
- Scanned PDFs without a text layer cannot be read.
- The compatibility score was calibrated on resume and job pairs labelled by category. It measures alignment with the job category and listed skills, not hiring outcomes. The score bands are data-derived cut-offs from that calibration set.
- Skill detection uses a fixed vocabulary of skills from the training job postings. Skills outside that vocabulary are not detected, and soft skills are detected less reliably than technical skills.
- CV and job description text are sent to the Gemini API. On the free tier, Google may use submitted content to improve its products, so do not submit confidential or personal information you would not want shared. Check Google's current terms.
- The application runs with the Flask development server on the local machine. It is not configured for public deployment.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| InconsistentVersionWarning when loading the classifier | Install the scikit-learn version used in Colab. In Colab run `import sklearn; print(sklearn.__version__)`, then run `pip install scikit-learn==<that version>`. |
| FileNotFoundError for an artifact | Check that every file listed above is in `artifacts/` with the exact name. |
| Gemini error: GEMINI_API_KEY is not set | Check that `.env` is in the project root and the variable name is correct, then restart the server. |
| Gemini error: model not found or not available | Change `GEMINI_MODEL` in `.env` to a model currently available in AI Studio and restart. |
| Analysis works but suggestions are unavailable | The score and skills do not depend on Gemini. Read the error shown under the career section and fix the key, model or rate limit. |
| Port 5000 is already in use | Change the `port` value in the last line of `app.py`. |
| Very slow first analysis | The embedding model is loading or downloading. Later analyses are faster. |